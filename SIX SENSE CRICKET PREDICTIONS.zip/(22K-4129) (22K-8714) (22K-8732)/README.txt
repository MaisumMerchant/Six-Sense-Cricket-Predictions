SIX SENSE CRICKET PREDICTIONS (SSCP)

Developers :

22K-4129 BAI-3A (MAISUM ABBAS)
22K-8714 BAI-3A (AMAN ULLAH KAZI)
22K-8732 BAI-3A (MUDASIR)

Libraries Required :

Pandas
Numpy
Scikit-Learn
Matplotlib
Tkinter